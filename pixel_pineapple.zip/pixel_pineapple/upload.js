// DOM elements
document.addEventListener('DOMContentLoaded', async function() {
  // Initialize DOM elements after the page has loaded
  window.analysisResults = document.getElementById('analysis-results');
  window.productForm = document.getElementById('product-form');
  window.apiKeyForm = document.getElementById('api-key-form');
  window.formDropArea = document.getElementById('form-drop-area');
  window.productImageInput = document.getElementById('productImageInput');
  window.productImagePreview = document.getElementById('product-image-preview');
  window.currentImage = null;
  
  // Get API key from storage first
  const hasApiKey = await getApiKey();
  
  if (hasApiKey) {
    // Show product form
    if (window.productForm) window.productForm.style.display = 'block';
    if (window.apiKeyForm) window.apiKeyForm.style.display = 'none';
    
    // Add event listener to product image input in the form
    if (productImageInput) {
      productImageInput.addEventListener('change', function(e) {
        if (e.target.files && e.target.files[0]) {
          updateProductImage(e.target.files[0]);
        }
      });
    }

    // Set up event listeners for the form drop area
    setupFormDropAreaEventListeners();
    
    // Set up product form event listeners
    setupProductFormListeners();
    
    // Show welcome message from pineapple
    showWelcomeMessage();
  } else {
    // Show API key form
    if (window.apiKeyForm) window.apiKeyForm.style.display = 'block';
    if (window.productForm) window.productForm.style.display = 'none';
  }
});

// Show welcome message from pineapple
function showWelcomeMessage() {
  // Display a fun welcome message in the speech bubble
  if (window.analysisResults) {
    window.analysisResults.innerHTML = `
      <div class="speech-bubble">
        <div class="speech-bubble-content">Hi there! I'm Pixel Pineapple! ^_^ Just upload your product image and enter the product name - I'll analyze the image and create everything else for you! Let's make an awesome marketing website!</div>
      </div>
    `;
    
    // Add a typing animation effect
    const content = document.querySelector('.speech-bubble-content');
    if (content) {
      const text = content.innerHTML;
      content.innerHTML = '';
      
      let i = 0;
      const typeWriter = () => {
        if (i < text.length) {
          content.innerHTML += text.charAt(i);
          i++;
          setTimeout(typeWriter, 20);
        }
      };
      
      typeWriter();
    }
  }
}

function setupProductFormListeners() {
  // Back button now shows welcome message again
  const backButton = document.getElementById('back-button');
  if (backButton) {
    backButton.addEventListener('click', function() {
      // Clear results and show welcome message
      if (window.analysisResults) {
        window.analysisResults.innerHTML = '';
        showWelcomeMessage();
      }
      
      // Hide marketing angles and clear progress containers
      const marketingAngles = document.getElementById('marketing-angles');
      if (marketingAngles) {
        marketingAngles.style.display = 'none';
      }
      
      // Clear any progress containers
      const progressContainers = document.querySelectorAll('.progress-container');
      progressContainers.forEach(container => container.remove());
      
      // Remove any pineapple animations
      const pineapple = document.querySelector('.logo');
      if (pineapple) {
        pineapple.classList.remove('pineapple-thinking', 'pineapple-working');
      }
    });
  }
  
  // Generate website button
  const generateButton = document.getElementById('generate-website');
  if (generateButton) {
    generateButton.addEventListener('click', function() {
      const productName = document.getElementById('product-name').value.trim();
      const productDescription = document.getElementById('product-description').value.trim();
      const productKeywords = document.getElementById('product-keywords').value.trim();
      
      if (!productName) {
        alert('Please enter a product name');
        return;
      }
      
      if (!productDescription || !productKeywords) {
        alert('Please upload a product image first so I can analyze it and generate the description and keywords!');
        return;
      }
      
      // Show loading state
      generateButton.disabled = true;
      generateButton.classList.add('loading');
      generateButton.textContent = 'Generating';
      
      // Generate marketing angles and images
      generateMarketingContent(productName, productDescription, productKeywords);
    });
  }
}

// We'll retrieve the Gemini API key from Chrome storage
let GEMINI_API_KEY = '';

// Function to detect product information from analysis text (DEPRECATED - now using AI-generated content)
// This function is kept for backwards compatibility but is no longer used
function detectProductInfo(analysisText) {
  // This function is deprecated - we now use AI-generated product analysis
  return {
    name: '',
    description: '',
    keywords: ''
  };
}

// Get API key from storage
function getApiKey() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['geminiApiKey'], function(result) {
      if (result.geminiApiKey) {
        GEMINI_API_KEY = result.geminiApiKey;
        resolve(true);
      } else {
        // No API key found, show the API key form
        const apiKeyForm = document.getElementById('api-key-form');
        const productForm = document.getElementById('product-form');
        
        if (apiKeyForm && productForm) {
          apiKeyForm.style.display = 'block';
          productForm.style.display = 'none';
          
          // Add event listener to the save button
          const saveButton = document.getElementById('save-api-key');
          if (saveButton) {
            saveButton.addEventListener('click', function() {
              const apiKeyInput = document.getElementById('gemini-api-key');
              if (apiKeyInput && apiKeyInput.value.trim()) {
                // Save the API key to storage
                chrome.storage.sync.set({ 'geminiApiKey': apiKeyInput.value.trim() }, function() {
                  // Update the global variable
                  GEMINI_API_KEY = apiKeyInput.value.trim();
                  
                  // Hide API key form and show product form
                  apiKeyForm.style.display = 'none';
                  productForm.style.display = 'block';
                  
                  // Initialize the product form
                  if (window.productImageInput) {
                    window.productImageInput.addEventListener('change', function(e) {
                      if (e.target.files && e.target.files[0]) {
                        updateProductImage(e.target.files[0]);
                      }
                    });
                  }
                  
                  // Set up event listeners for the form drop area
                  setupFormDropAreaEventListeners();
                  
                  // Set up product form event listeners
                  setupProductFormListeners();
                  
                  // Show welcome message from pineapple
                  showWelcomeMessage();
                  
                  // Resolve the promise
                  resolve(true);
                });
              } else {
                // Show error if API key is empty
                alert('Please enter a valid Gemini API key');
              }
            });
          }
        }
        
        resolve(false);
      }
    });
  });
}

// Function to set up all event listeners
function setupEventListeners() {
  if (!window.dropArea) return;
  
  // Prevent default drag behaviors
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    window.dropArea.addEventListener(eventName, preventDefaults, false);
    document.body.addEventListener(eventName, preventDefaults, false);
  });

  // Highlight drop area when item is dragged over it
  ['dragenter', 'dragover'].forEach(eventName => {
    window.dropArea.addEventListener(eventName, highlight, false);
  });

  ['dragleave', 'drop'].forEach(eventName => {
    window.dropArea.addEventListener(eventName, unhighlight, false);
  });

  // Handle dropped files
  window.dropArea.addEventListener('drop', handleDrop, false);
}

// Prevent default behavior (browser opening/reading the file)
function preventDefaults(e) {
  e.preventDefault();
  e.stopPropagation();
}

function highlight() {
  if (window.dropArea) {
    window.dropArea.classList.add('highlight');
  }
}

function unhighlight() {
  if (window.dropArea) {
    window.dropArea.classList.remove('highlight');
  }
}

function handleDrop(e) {
  let dt = e.dataTransfer;
  let files = dt.files;
  
  handleFiles(files);
}

function handleFiles(files) {
  [...files].forEach(uploadFile);
}

function uploadFile(file) {
  // Check if file is an image
  if (!file.type.match('image.*')) {
    alert('Only image files are supported');
    return;
  }
  
  // Check if the file type is supported by Gemini API
  const supportedTypes = ["image/jpeg", "image/png", "image/webp", "image/heic", "image/heif"];
  if (!supportedTypes.includes(file.type)) {
    console.warn(`Image type ${file.type} may not be supported by Gemini API. For best results, use JPEG, PNG, or WebP.`);
  }
  
  let reader = new FileReader();
  
  reader.onload = function(e) {
    // Hide the drop area after upload
    if (window.dropArea) {
      window.dropArea.style.display = 'none';
    }
    
  // Add pineapple thinking animation during analysis
  const pineapple = document.querySelector('.logo');
  if (pineapple) {
    pineapple.classList.add('pineapple-thinking');
  }
  
  // Show loading message in speech bubble
  if (window.analysisResults) {
    window.analysisResults.innerHTML = `
      <div class="speech-bubble typing">
        <div class="speech-bubble-content">Let me take a look at this image<span class="loading-dots"></span></div>
      </div>
    `;
  }
    
    // Create new image thumbnail
    let img = document.createElement('img');
    img.src = e.target.result;
    img.title = file.name;
    img.addEventListener('click', function() {
      // Open the image in full size in a new tab when clicked
      let newTab = window.open();
      newTab.document.write('<img src="' + e.target.result + '" alt="' + file.name + '" style="max-width: 100%;">');
    });
    window.gallery.appendChild(img);
    
    // Save current image for marketing generation
    window.currentImage = e.target.result;
    
    // Save to local storage for persistence
    saveToLocalStorage(e.target.result, file.name);
    
    // Send to Gemini for analysis
    analyzeImageWithGemini(e.target.result, file.type);
  };
  
  reader.readAsDataURL(file);
}

// Function to save images to local storage
function saveToLocalStorage(dataUrl, filename) {
  // Get existing stored images or initialize empty array
  let storedImages = JSON.parse(localStorage.getItem('pixelPineappleImages')) || [];
  
  // Add new image (limit to most recent 10 images to manage storage)
  storedImages.push({
    dataUrl: dataUrl,
    filename: filename,
    timestamp: Date.now()
  });
  
  // Keep only the most recent 10 images
  if (storedImages.length > 10) {
    storedImages = storedImages.slice(-10);
  }
  
  // Save back to local storage
  try {
    localStorage.setItem('pixelPineappleImages', JSON.stringify(storedImages));
  } catch (e) {
    console.error('Storage failed: Likely exceeded quota', e);
    // If we exceed storage quota, remove the oldest item and try again
    if (storedImages.length > 1) {
      storedImages.shift();
      localStorage.setItem('pixelPineappleImages', JSON.stringify(storedImages));
    }
  }
}

// Function to analyze image with Gemini API
async function analyzeImageWithGemini(imageDataUrl, mimeType) {
  // Check if we have an API key
  if (!GEMINI_API_KEY) {
    const hasApiKey = await getApiKey();
    if (!hasApiKey) {
      window.analysisResults.innerHTML = `
        <div class="analysis-error">
          <h3>API Key Required</h3>
          <p>Please set your Gemini API key in the extension options.</p>
          <button id="open-options">Set API Key</button>
        </div>
      `;
      
      document.getElementById('open-options').addEventListener('click', function() {
        chrome.runtime.openOptionsPage();
      });
      
      // Remove loading indicator if it exists
      const loadingIndicator = document.getElementById('loading-indicator');
      if (loadingIndicator) {
        loadingIndicator.remove();
      }
      
      return;
    }
  }
  
  // Check if the image data URL is valid
  if (!imageDataUrl || !imageDataUrl.startsWith('data:image/')) {
    window.analysisResults.innerHTML = `
      <div class="speech-bubble">
        <div class="speech-bubble-content">Oops! That doesn't look like a valid image. Please try uploading a different image.</div>
      </div>
    `;
    return;
  }
  
  // Extract the base64 data from the data URL (remove the prefix)
  const base64Data = imageDataUrl.split(',')[1];
  
  // List of supported MIME types by Gemini
  const supportedMimeTypes = [
    "image/jpeg", 
    "image/png", 
    "image/webp", 
    "image/heic", 
    "image/heif"
  ];
  
  // Make sure we have a valid MIME type
  let imageMimeType = mimeType || "image/jpeg";
  
  // Check if the MIME type is supported, if not, default to JPEG
  if (!supportedMimeTypes.includes(imageMimeType)) {
    console.warn(`MIME type ${imageMimeType} not supported by Gemini API, defaulting to image/jpeg`);
    imageMimeType = "image/jpeg";
  }
  
  // Prepare the request to Gemini API with a comprehensive product analysis prompt
  const requestData = {
    contents: [{
      parts: [
        { text: `You are a product marketing expert analyzing a product image. Please provide a comprehensive analysis in the following JSON format:

{
  "friendly_description": "A fun, enthusiastic description of what you see in the image (2-3 sentences)",
  "product_description": "A detailed, professional product description highlighting features, benefits, and target audience (3-4 sentences)",
  "keywords": ["keyword1", "keyword2", "keyword3", "keyword4", "keyword5"]
}

Guidelines:
- friendly_description: Be enthusiastic and conversational, like you're talking to a friend
- product_description: Professional marketing copy that highlights key features, benefits, and who would use this product
- keywords: 5 relevant marketing keywords that describe the product's style, features, or benefits

Focus on what makes this product special and appealing to potential customers.` },
        {
          inline_data: {
            mime_type: imageMimeType,
            data: base64Data
          }
        }
      ]
    }],
    generationConfig: {
      temperature: 0.7,
      topK: 32,
      topP: 1,
      maxOutputTokens: 1024
    }
  };
  
  // Send the request to Gemini API with better error handling
  try {
    console.log('Sending analysis request to Gemini API...');
    console.log('Request data:', JSON.stringify(requestData).substring(0, 500) + '...');
    
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestData)
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('API error response:', errorText);
      throw new Error(`API request failed with status: ${response.status}. Details: ${errorText.substring(0, 200)}...`);
    }
    
    const data = await response.json();
    console.log('Received analysis response:', data);
    
    // Remove loading indicator
    const loadingIndicator = document.getElementById('loading-indicator');
    if (loadingIndicator) {
      loadingIndicator.remove();
    }
    
    // Display the analysis results
    displayAnalysisResults(data);
  } catch (error) {
    console.error('Error analyzing image with Gemini:', error);
    
    // Remove loading indicator
    const loadingIndicator = document.getElementById('loading-indicator');
    if (loadingIndicator) {
      loadingIndicator.remove();
    }
    
    // Show error message in speech bubble
    window.analysisResults.innerHTML = `
      <div class="speech-bubble">
        <div class="speech-bubble-content">Oops! I couldn't analyze that image. There was an error: ${error.message}. Please try again with a different image or check your API key.</div>
      </div>
    `;
  }
}

// Function to display analysis results from Gemini
function displayAnalysisResults(data) {
  // Extract the text from the response
  let analysisText = '';
  
  try {
    // Navigate the response structure to get the generated text
    if (data.candidates && data.candidates.length > 0 && 
        data.candidates[0].content && data.candidates[0].content.parts && 
        data.candidates[0].content.parts.length > 0) {
      analysisText = data.candidates[0].content.parts[0].text;
    } else {
      throw new Error('Unexpected API response structure');
    }
    
    // Parse the JSON response
    let productAnalysis = {};
    try {
      // Extract JSON from the text (in case there's surrounding text)
      const jsonMatch = analysisText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        productAnalysis = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('No JSON found in response');
      }
    } catch (parseError) {
      console.error('Error parsing JSON response:', parseError);
      // Fallback to displaying raw text
      document.getElementById('analysis-results').innerHTML = `
        <div class="speech-bubble">
          <div class="speech-bubble-content">${analysisText.replace(/\n/g, '<br>')}</div>
        </div>
      `;
      return;
    }
    
    // Store the analysis data globally
    window.productAnalysis = productAnalysis;
    
    // Remove pineapple thinking animation
    const pineapple = document.querySelector('.logo');
    if (pineapple) {
      pineapple.classList.remove('pineapple-thinking');
    }
    
    // Display the friendly description in the speech bubble
    document.getElementById('analysis-results').innerHTML = `
      <div class="speech-bubble">
        <div class="speech-bubble-content">${productAnalysis.friendly_description || analysisText}</div>
      </div>
    `;
    
    // Auto-fill form with AI-generated content
    if (productAnalysis.product_description) {
      document.getElementById('product-description').value = productAnalysis.product_description;
    }
    if (productAnalysis.keywords && Array.isArray(productAnalysis.keywords)) {
      document.getElementById('product-keywords').value = productAnalysis.keywords.join(', ');
    }
    
    // Add a typing animation effect
    const content = document.querySelector('.speech-bubble-content');
    const text = content.innerHTML;
    content.innerHTML = '';
    
    let i = 0;
    const typeWriter = () => {
      if (i < text.length) {
        content.innerHTML += text.charAt(i);
        i++;
        setTimeout(typeWriter, 20); // Adjust speed as needed
      }
    };
    
    typeWriter();
    
  } catch (error) {
    console.error('Error parsing Gemini response:', error);
    document.getElementById('analysis-results').innerHTML = `
      <div class="speech-bubble">
        <div class="speech-bubble-content">Oops! I couldn't analyze that image. Can you try again with a different one? (o_o)</div>
      </div>
    `;
  }
}

// Set up drag-and-drop for the product form image upload area
function setupFormDropAreaEventListeners() {
  if (!window.formDropArea) return;
  
  // Prevent default drag behaviors
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    window.formDropArea.addEventListener(eventName, preventDefaults, false);
  });

  // Highlight drop area when item is dragged over it
  ['dragenter', 'dragover'].forEach(eventName => {
    window.formDropArea.addEventListener(eventName, function() {
      window.formDropArea.classList.add('highlight');
    });
  });

  ['dragleave', 'drop'].forEach(eventName => {
    window.formDropArea.addEventListener(eventName, function() {
      window.formDropArea.classList.remove('highlight');
    });
  });

  // Handle dropped files
  window.formDropArea.addEventListener('drop', function(e) {
    let dt = e.dataTransfer;
    let files = dt.files;
    
    if (files && files.length > 0) {
      updateProductImage(files[0]);
    }
  });
}

// Update the product image in the form and analyze it
function updateProductImage(file) {
  if (!file.type.match('image.*')) {
    alert('Please select an image file.');
    return;
  }
  
  // Check if the file type is supported by Gemini API
  const supportedTypes = ["image/jpeg", "image/png", "image/webp", "image/heic", "image/heif"];
  if (!supportedTypes.includes(file.type)) {
    console.warn(`Image type ${file.type} may not be supported by Gemini API. For best results, use JPEG, PNG, or WebP.`);
  }
  
  // Add pineapple thinking animation during analysis
  const pineapple = document.querySelector('.logo');
  if (pineapple) {
    pineapple.classList.add('pineapple-thinking');
  }
  
  // Show loading message in speech bubble
  if (window.analysisResults) {
    window.analysisResults.innerHTML = `
      <div class="speech-bubble typing">
        <div class="speech-bubble-content">Analyzing your product image<span class="loading-dots"></span></div>
      </div>
    `;
  }
  
  let reader = new FileReader();
  reader.onload = function(e) {
    // Update current image for marketing generation
    window.currentImage = e.target.result;
    
    // Display the image in the preview area
    if (window.productImagePreview) {
      window.productImagePreview.innerHTML = '';
      const img = document.createElement('img');
      img.src = e.target.result;
      img.alt = 'Product image';
      window.productImagePreview.appendChild(img);
    }
    
    // Send to Gemini for analysis
    analyzeImageWithGemini(e.target.result, file.type);
  };
  
  reader.readAsDataURL(file);
}

// Function to show the product form (not needed anymore since form is always visible)
// Kept for backwards compatibility
function showProductForm() {
  // This function is deprecated - form is always visible and AI generates content
  // No action needed
}

// Function to create progress container
function createProgressContainer() {
  const container = document.createElement('div');
  container.className = 'progress-container';
  container.innerHTML = `
    <h4>Creating Your Marketing Content</h4>
    <div class="progress-step pending" data-step="1">
      <div class="step-icon pending">1</div>
      <div class="step-text">Generate marketing angles</div>
    </div>
    <div class="progress-step pending" data-step="2">
      <div class="step-icon pending">2</div>
      <div class="step-text">Create marketing images</div>
    </div>
    <div class="progress-step pending" data-step="3">
      <div class="step-icon pending">3</div>
      <div class="step-text">Prepare website content</div>
    </div>
  `;
  return container;
}

// Function to update progress step
function updateProgressStep(container, stepNumber, status, text) {
  console.log(`Updating step ${stepNumber} to ${status}: ${text}`);
  const step = container.querySelector(`[data-step="${stepNumber}"]`);
  if (step) {
    step.className = `progress-step ${status}`;
    const icon = step.querySelector('.step-icon');
    const stepText = step.querySelector('.step-text');
    
    if (icon) {
      icon.className = `step-icon ${status}`;
      if (status === 'completed') {
        icon.innerHTML = '&check;';
      } else if (status === 'error') {
        icon.innerHTML = '&times;';
      } else {
        icon.textContent = stepNumber;
      }
    }
    
    if (stepText && text) {
      stepText.textContent = text;
    }
  } else {
    console.error(`Step ${stepNumber} not found in container:`, container);
  }
}

// Function to generate marketing content - both text angles and visual content
async function generateMarketingContent(productName, productDescription, keywords) {
  const marketingAngles = document.getElementById('marketing-angles');
  const anglesContainer = document.getElementById('angles-container');
  
  // Add pineapple thinking animation
  const pineapple = document.querySelector('.logo');
  if (pineapple) {
    pineapple.classList.add('pineapple-thinking');
  }
  
  // Show marketing angles section and progress container
  marketingAngles.style.display = 'block';
  anglesContainer.innerHTML = ''; // Clear any existing content
  
  // Add a simple loading message as fallback
  const loadingMessage = document.createElement('div');
  loadingMessage.id = 'loading-message';
  loadingMessage.className = 'loading-message';
  loadingMessage.innerHTML = '<p style="color: #4CAF50; font-weight: bold;">Generating your marketing content...</p>';
  anglesContainer.appendChild(loadingMessage);
  
  const progressContainer = createProgressContainer();
  anglesContainer.appendChild(progressContainer);
  
  console.log('Progress container created and added:', progressContainer);
  
  // Store the content for website generation
  window.marketingData = {
    name: productName,
    description: productDescription,
    keywords: typeof keywords === 'string' ? keywords.split(',').map(k => k.trim()) : [],
    angles: [],
    images: []
  };
  
  try {
    // Step 1: Generate marketing text angles
    updateProgressStep(progressContainer, 1, 'active', 'Generating marketing angles...');
    await generateMarketingAngles(productName, productDescription, keywords);
    updateProgressStep(progressContainer, 1, 'completed', 'Marketing angles generated!');
    
    // Remove the simple loading message
    const loadingMessage = document.getElementById('loading-message');
    if (loadingMessage) {
      loadingMessage.remove();
    }
    
    // Step 2: Generate marketing images
    if (window.currentImage) {
      updateProgressStep(progressContainer, 2, 'active', 'Creating marketing images...');
      await generateMarketingImages(productName, productDescription, window.currentImage);
      updateProgressStep(progressContainer, 2, 'completed', 'Marketing images created!');
    }
    
    // Step 3: Prepare for website generation
    updateProgressStep(progressContainer, 3, 'active', 'Preparing website content...');
    await new Promise(resolve => setTimeout(resolve, 1000)); // Brief pause for effect
    updateProgressStep(progressContainer, 3, 'completed', 'Ready to create website!');
    
    // Remove pineapple thinking animation
    if (pineapple) {
      pineapple.classList.remove('pineapple-thinking');
      pineapple.classList.add('pineapple-working');
    }
    
    // Show results UI
    marketingAngles.style.display = 'block';
    
    // Enable the button again
    const generateButton = document.getElementById('generate-website');
    if (generateButton) {
      generateButton.disabled = false;
      generateButton.textContent = 'Generate Website';
      generateButton.classList.remove('loading');
    }
    
    // Add a button to generate the final website
    const websiteButton = document.createElement('button');
    websiteButton.id = 'create-final-website';
    websiteButton.textContent = 'Create Product Website';
    websiteButton.className = 'button';
    websiteButton.style.marginTop = '20px';
    websiteButton.style.minWidth = '200px'; // Ensure consistent width
    websiteButton.style.display = 'inline-block'; // Prevent layout shifts
    websiteButton.addEventListener('click', async function() {
      // Remove the button immediately when clicked
      websiteButton.remove();
      
      // Add pineapple working animation
      if (pineapple) {
        pineapple.classList.add('pineapple-working');
      }
      
      await createProductWebsite(window.marketingData);
      
      // Remove pineapple working animation
      if (pineapple) {
        pineapple.classList.remove('pineapple-working');
      }
    });
    
    anglesContainer.appendChild(document.createElement('hr'));
    anglesContainer.appendChild(websiteButton);
    
  } catch (error) {
    console.error('Error generating marketing content:', error);
    
    // Remove pineapple animation
    if (pineapple) {
      pineapple.classList.remove('pineapple-thinking', 'pineapple-working');
    }
    
    // Show error in progress
    updateProgressStep(progressContainer, 1, 'error', 'Error generating content. Please try again.');
    
    // Enable the button again
    const generateButton = document.getElementById('generate-website');
    if (generateButton) {
      generateButton.disabled = false;
      generateButton.textContent = 'Generate Website';
      generateButton.classList.remove('loading');
    }
  }
}

// Function to generate marketing text angles with Gemini
async function generateMarketingAngles(productName, productDescription, keywords) {
  const anglesContainer = document.getElementById('angles-container');
  // Don't clear the container here - we want to keep the progress container
  
  // Check if we have an API key
  if (!GEMINI_API_KEY) {
    const hasApiKey = await getApiKey();
    if (!hasApiKey) {
      throw new Error('API key not found');
    }
  }
  
  // Prepare the request to Gemini API
  const requestData = {
    contents: [{
      parts: [
        {
          text: `You are a marketing expert that specializes in creating compelling product descriptions and marketing angles.
          
          Your task is to carefully analyze the specific product details I'll provide and create 3 different marketing angles that are HIGHLY RELEVANT to this exact product. 
          
          Each angle should:
          1. Have a title that directly references the product or its key benefits
          2. Include a compelling paragraph that specifically addresses how this particular product solves problems or delivers value
          3. Appeal to different customer segments or highlight different aspects of this specific product
          4. Use language and tone that would resonate with the target audience for this exact product
          5. Incorporate the provided keywords naturally
          
          DO NOT generate generic marketing content. Your angles must be tailored to the exact product described.
          
          Format your response as JSON in the following structure:
          {
            "angles": [
              {
                "title": "Product-Specific Title 1",
                "description": "Compelling paragraph for this specific product angle 1"
              },
              {
                "title": "Product-Specific Title 2", 
                "description": "Compelling paragraph for this specific product angle 2"
              },
              {
                "title": "Product-Specific Title 3",
                "description": "Compelling paragraph for this specific product angle 3"
              }
            ]
          }`
        },
        {
          text: `Product Name: ${productName}\n\nProduct Description: ${productDescription}\n\nKeywords: ${keywords}\n\nIMPORTANT: Your marketing angles MUST be specifically tailored to this exact product. Use concrete details from the product description.`
        }
      ]
    }]
  };
  
  // Send the request to Gemini API with better error handling
  console.log('Sending marketing angles request to Gemini API...');
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(requestData)
  });
  
  if (!response.ok) {
    throw new Error(`API request failed with status: ${response.status}`);
  }
  
  const data = await response.json();
  
  // Extract the text from the response
  let anglesText = '';
  
  if (data.candidates && data.candidates.length > 0 && 
      data.candidates[0].content && data.candidates[0].content.parts && 
      data.candidates[0].content.parts.length > 0) {
    anglesText = data.candidates[0].content.parts[0].text;
  } else {
    throw new Error('Unexpected API response structure');
  }
  
  // Parse the JSON response
  let angles = [];
  try {
    // Extract JSON from the text (in case there's surrounding text)
    const jsonMatch = anglesText.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const anglesJson = JSON.parse(jsonMatch[0]);
      angles = anglesJson.angles || [];
    }
  } catch (error) {
    console.error('Error parsing angles JSON:', error);
    throw new Error('Failed to parse marketing angles');
  }
  
  // Store the angles for website generation
  window.marketingData.angles = angles;
  
  // Display the angles (append after progress container)
  const anglesSection = document.createElement('div');
  anglesSection.className = 'marketing-angles-content';
  anglesSection.innerHTML = '<h4>Marketing Angles</h4>';
  
  angles.forEach((angle, index) => {
    const angleElement = document.createElement('div');
    angleElement.className = 'angle';
    angleElement.innerHTML = `
      <h4>${angle.title}</h4>
      <p>${angle.description}</p>
    `;
    anglesSection.appendChild(angleElement);
  });
  
  anglesContainer.appendChild(anglesSection);
  
  return angles;
}

// Function to generate marketing images with Gemini image preview model
async function generateMarketingImages(productName, productDescription, imageDataUrl) {
  if (!imageDataUrl) return [];
  
  // Extract the base64 data from the data URL (remove the prefix)
  const base64Data = imageDataUrl.split(',')[1];
  
  // Check if we have an API key
  if (!GEMINI_API_KEY) {
    const hasApiKey = await getApiKey();
    if (!hasApiKey) {
      throw new Error('API key not found');
    }
  }
  
  // Add a message to the angles container
  const anglesContainer = document.getElementById('angles-container');
  const imageSection = document.createElement('div');
  imageSection.className = 'marketing-images';
  imageSection.innerHTML = '<h4>Marketing Images</h4><p>Generating marketing images...</p>';
  anglesContainer.appendChild(imageSection);
  
      // Marketing image prompts - specifically for image editing with Gemini
      const imagePrompts = [
        `Transform this product image into a lifestyle scene showing the ${productName} being used by a happy customer in a modern setting. Edit this image to make the product the focus while adding appropriate context and environment.`,
        `Edit this product image to create a clean, minimal product showcase of the ${productName} on a white background that highlights its features. Remove any distractions and make the product stand out.`,
        `Using this product image as a base, create a promotional banner for ${productName} that would look good on social media with vibrant colors and modern design elements. Keep the product recognizable but enhance the visual appeal.`
      ];
  
  const images = [];
  
  // Generate each image
  for (let i = 0; i < imagePrompts.length; i++) {
    try {
      // Prepare the request to Gemini API for image editing (with input image)
      const requestData = {
        contents: [{
          parts: [
            {
              text: imagePrompts[i]
            },
            {
              inline_data: {
                mime_type: "image/jpeg",
                data: base64Data
              }
            }
          ]
        }]
      };
      
      // Send the request to Gemini API - use gemini-2.5-flash-image-preview for image editing
      // This model can transform existing images based on text prompts
      console.log('Sending image generation request to Gemini API...');
      console.log('Request data:', JSON.stringify(requestData).substring(0, 200) + '...');
      
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image-preview:generateContent?key=${GEMINI_API_KEY}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestData)
      });
      
      // Log for debugging
      console.log('Image generation request sent for prompt:', imagePrompts[i]);
      
      if (!response.ok) {
        throw new Error(`API request failed with status: ${response.status}`);
      }
      
      const data = await response.json();
      
      // Extract the image data and add debugging
      console.log('Received API response:', JSON.stringify(data).substring(0, 500) + '...');
      
      // Extract the image data from response
      let imageData = null;
      if (data.candidates && data.candidates.length > 0 && 
          data.candidates[0].content && data.candidates[0].content.parts) {
        
        console.log('Found candidates and parts');
        console.log('Number of parts:', data.candidates[0].content.parts.length);
        
        for (const part of data.candidates[0].content.parts) {
          const partType = part.text ? 'text' : (part.inline_data || part.inlineData) ? 'inline_data' : 'unknown';
          console.log('Examining part type:', partType);
          
          if (partType === 'text') {
            console.log('Text content:', part.text.substring(0, 100) + '...');
          }
          
          // Check for both snake_case and camelCase versions of the property
          if ((part.inline_data && part.inline_data.mime_type && part.inline_data.mime_type.startsWith('image/')) || 
              (part.inlineData && part.inlineData.mimeType && part.inlineData.mimeType.startsWith('image/'))) {
            
            // Handle both formats (API returns camelCase but our code was looking for snake_case)
            const mimeType = part.inline_data ? part.inline_data.mime_type : part.inlineData.mimeType;
            const data = part.inline_data ? part.inline_data.data : part.inlineData.data;
            
            console.log('Found image data:', mimeType);
            console.log('Image data length:', data ? data.length : 'none');
            imageData = `data:${mimeType};base64,${data}`;
            break;
          }
        }
      }
      
      if (imageData) {
        // Compress the generated image to reduce file size
        try {
          const compressedImageData = await compressImageDataUrl(imageData, 800, 0.8);
          images.push({
            dataUrl: compressedImageData,
            description: imagePrompts[i]
          });
        } catch (compressionError) {
          console.warn('Failed to compress generated image, using original:', compressionError);
          images.push({
            dataUrl: imageData,
            description: imagePrompts[i]
          });
        }
        
        // Add image to the display
        const imgContainer = document.createElement('div');
        imgContainer.style.marginBottom = '20px';
        
        const img = document.createElement('img');
        img.src = images[images.length - 1].dataUrl; // Use the compressed version
        img.alt = `Marketing image ${i+1}`;
        img.style.maxWidth = '100%';
        img.style.margin = '10px 0';
        img.style.border = '1px solid #ddd';
        img.style.borderRadius = '5px';
        
        const description = document.createElement('div');
        description.className = 'image-description';
        description.innerHTML = `<h4>Marketing Image ${i+1}</h4><p>${imagePrompts[i]}</p>`;
        description.style.backgroundColor = '#f9f9f9';
        description.style.padding = '10px';
        description.style.borderRadius = '5px';
        description.style.marginTop = '10px';
        
        // Update image section
        if (i === 0) {
          imageSection.innerHTML = '<h4>Marketing Images</h4>';
        }
        
        imgContainer.appendChild(img);
        imgContainer.appendChild(description);
        imageSection.appendChild(imgContainer);
      }
    } catch (error) {
      console.error(`Error generating image ${i+1}:`, error);
      
      // Add error info to the UI
      const errorInfo = document.createElement('div');
      errorInfo.innerHTML = `<p style="color: red;">Error generating image ${i+1}: ${error.message}</p>`;
      imageSection.appendChild(errorInfo);
      
      // Continue with the next image
    }
  }
  
  // Store the images for website generation
  window.marketingData.images = images;
  
  return images;
}

// Function to create the final product website
async function createProductWebsite(marketingData) {
  // Update UI to show generation is in progress
  const anglesContainer = document.getElementById('angles-container');
  
  // Add a simple loading message (same as marketing angles)
  const loadingMessage = document.createElement('div');
  loadingMessage.id = 'website-loading-message';
  loadingMessage.className = 'loading-message';
  loadingMessage.innerHTML = '<p style="color: #4CAF50; font-weight: bold;">Pixel Pineapple is crafting your website...</p>';
  anglesContainer.appendChild(loadingMessage);
  
  // Add fun animated messages
  const funMessages = [
    "Designing the layout...",
    "Adding marketing content...",
    "Integrating images...",
    "Creating call-to-actions...",
    "Applying styling...",
    "Almost ready to launch!"
  ];
  
  let messageIndex = 0;
  const messageInterval = setInterval(() => {
    if (messageIndex < funMessages.length) {
      loadingMessage.innerHTML = `<p style="color: #4CAF50; font-weight: bold;">${funMessages[messageIndex]}</p>`;
      messageIndex++;
    }
  }, 1500);
  
  // Create website generation progress container
  const websiteProgressContainer = document.createElement('div');
  websiteProgressContainer.className = 'progress-container';
  websiteProgressContainer.innerHTML = `
    <h4>Creating Your Product Website</h4>
    <div class="progress-step pending" data-step="1">
      <div class="step-icon pending">1</div>
      <div class="step-text">Connecting to AI...</div>
    </div>
    <div class="progress-step pending" data-step="2">
      <div class="step-icon pending">2</div>
      <div class="step-text">Analyzing your product...</div>
    </div>
    <div class="progress-step pending" data-step="3">
      <div class="step-icon pending">3</div>
      <div class="step-text">Designing website layout...</div>
    </div>
    <div class="progress-step pending" data-step="4">
      <div class="step-icon pending">4</div>
      <div class="step-text">Adding marketing content...</div>
    </div>
    <div class="progress-step pending" data-step="5">
      <div class="step-icon pending">5</div>
      <div class="step-text">Integrating images...</div>
    </div>
    <div class="progress-step pending" data-step="6">
      <div class="step-icon pending">6</div>
      <div class="step-text">Applying styling...</div>
    </div>
    <div class="progress-step pending" data-step="7">
      <div class="step-icon pending">7</div>
      <div class="step-text">Finalizing website...</div>
    </div>
  `;
  anglesContainer.appendChild(websiteProgressContainer);
  
  try {
    // Step 1: Connecting to AI
    updateProgressStep(websiteProgressContainer, 1, 'active', 'Connecting to Gemini API...');
    await new Promise(resolve => setTimeout(resolve, 1000));
    updateProgressStep(websiteProgressContainer, 1, 'completed', 'Connected successfully!');
    
    // Step 2: Analyzing product
    updateProgressStep(websiteProgressContainer, 2, 'active', 'Analyzing your product...');
    await new Promise(resolve => setTimeout(resolve, 1200));
    updateProgressStep(websiteProgressContainer, 2, 'completed', 'Product analyzed!');
    
    // Step 3: Designing layout
    updateProgressStep(websiteProgressContainer, 3, 'active', 'Designing website layout...');
    await new Promise(resolve => setTimeout(resolve, 1000));
    updateProgressStep(websiteProgressContainer, 3, 'completed', 'Layout designed!');
    
    // Step 4: Adding marketing content
    updateProgressStep(websiteProgressContainer, 4, 'active', 'Adding marketing content...');
    await new Promise(resolve => setTimeout(resolve, 800));
    updateProgressStep(websiteProgressContainer, 4, 'completed', 'Content added!');
    
    // Step 5: Integrating images
    updateProgressStep(websiteProgressContainer, 5, 'active', 'Integrating images...');
    await new Promise(resolve => setTimeout(resolve, 600));
    updateProgressStep(websiteProgressContainer, 5, 'completed', 'Images integrated!');
    
    // Step 6: Applying styling
    updateProgressStep(websiteProgressContainer, 6, 'active', 'Applying styling...');
    const websiteHTML = await generateWebsiteHTML(marketingData);
    updateProgressStep(websiteProgressContainer, 6, 'completed', 'Styling applied!');
    
    // Step 7: Finalizing
    updateProgressStep(websiteProgressContainer, 7, 'active', 'Finalizing website...');
    await new Promise(resolve => setTimeout(resolve, 800));
    updateProgressStep(websiteProgressContainer, 7, 'completed', 'Website ready!');
    
    // Clear the message interval and remove the loading message
    clearInterval(messageInterval);
    const loadingMessage = document.getElementById('website-loading-message');
    if (loadingMessage) {
      loadingMessage.remove();
    }
    
    // Create a download link for the HTML file
    const blob = new Blob([websiteHTML], {type: 'text/html'});
    const url = URL.createObjectURL(blob);
    
    const downloadLink = document.createElement('a');
    downloadLink.href = url;
    downloadLink.download = `${marketingData.name.replace(/\s+/g, '-').toLowerCase()}-website.html`;
    downloadLink.textContent = 'Download Website HTML';
    downloadLink.className = 'button';
    downloadLink.style.display = 'inline-block';
    downloadLink.style.marginRight = '10px';
    downloadLink.style.marginTop = '20px';
    
    // Create a view button
    const viewButton = document.createElement('button');
    viewButton.textContent = 'View Website';
    viewButton.className = 'button';
    viewButton.style.marginTop = '20px';
    viewButton.addEventListener('click', function() {
      // Open the website in a new tab
      const newTab = window.open();
      newTab.document.write(websiteHTML);
      newTab.document.close();
    });
    
    // Add the buttons
    websiteProgressContainer.appendChild(downloadLink);
    websiteProgressContainer.appendChild(viewButton);
    
    // Add a success celebration message
    const successMessage = document.createElement('div');
    successMessage.style.cssText = `
      background: linear-gradient(135deg, #4CAF50, #45a049);
      color: white;
      padding: 15px;
      border-radius: 8px;
      margin: 20px 0;
      text-align: center;
      font-weight: bold;
      animation: pulse 2s infinite;
    `;
    successMessage.textContent = 'Your website is ready!';
    websiteProgressContainer.appendChild(successMessage);
    
    // Automatically open the website in a new tab
    setTimeout(() => {
      const newTab = window.open();
      newTab.document.write(websiteHTML);
      newTab.document.close();
    }, 1500);
    
  } catch (error) {
    console.error('Error creating website:', error);
    updateProgressStep(websiteProgressContainer, 1, 'error', `Error: ${error.message}`);
  }
}

// Function to compress image data URL to reduce file size
function compressImageDataUrl(dataUrl, maxWidth = 800, quality = 0.8) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = function() {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      // Calculate new dimensions
      let { width, height } = img;
      if (width > maxWidth) {
        height = (height * maxWidth) / width;
        width = maxWidth;
      }
      
      canvas.width = width;
      canvas.height = height;
      
      // Draw and compress
      ctx.drawImage(img, 0, 0, width, height);
      const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
      
      console.log(`Image compressed: ${dataUrl.length} -> ${compressedDataUrl.length} characters`);
      resolve(compressedDataUrl);
    };
    img.src = dataUrl;
  });
}

// Function to clean HTML output and remove markdown artifacts
function cleanHTMLOutput(html) {
  console.log('Cleaning HTML output...');
  
  // Remove markdown code block markers
  let cleanedHTML = html
    .replace(/^```html\s*/gi, '')  // Remove opening ```html
    .replace(/^```\s*$/gm, '')      // Remove closing ```
    .replace(/^```\s*/gm, '')      // Remove any remaining ```
    .trim();
  
  // Ensure it starts with DOCTYPE
  if (!cleanedHTML.startsWith('<!DOCTYPE')) {
    // Find the first <!DOCTYPE or <html tag
    const doctypeMatch = cleanedHTML.match(/<!DOCTYPE[^>]*>/i);
    const htmlMatch = cleanedHTML.match(/<html[^>]*>/i);
    
    if (doctypeMatch) {
      cleanedHTML = cleanedHTML.substring(cleanedHTML.indexOf(doctypeMatch[0]));
    } else if (htmlMatch) {
      cleanedHTML = '<!DOCTYPE html>\n' + cleanedHTML.substring(cleanedHTML.indexOf(htmlMatch[0]));
    }
  }
  
  // Remove any leading text before DOCTYPE
  const doctypeIndex = cleanedHTML.indexOf('<!DOCTYPE');
  if (doctypeIndex > 0) {
    cleanedHTML = cleanedHTML.substring(doctypeIndex);
  }
  
  console.log('HTML cleaned successfully');
  return cleanedHTML;
}

// Function to replace image placeholders with actual images
function replaceImagePlaceholders(websiteHTML, images) {
  console.log('Starting image placeholder replacement...');
  console.log('Available images:', images.length);
  
  let processedHTML = websiteHTML;
  
  // First, try to replace our specific placeholders
  for (let i = 0; i < images.length; i++) {
    const placeholder = `<!-- IMAGE_PLACEHOLDER_${i + 1} -->`;
    const imageData = images[i];
    
    if (imageData && imageData.dataUrl) {
      // Create a proper img tag with the image data
      const imgTag = `<img src="${imageData.dataUrl}" alt="Marketing Image ${i + 1}" style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">`;
      
      // Replace the placeholder with the img tag
      processedHTML = processedHTML.replace(placeholder, imgTag);
      console.log(`Replaced placeholder ${i + 1} with image`);
    } else {
      console.warn(`No image data available for placeholder ${i + 1}`);
      // Replace with a fallback placeholder
      const fallbackImg = `<div style="width: 100%; height: 300px; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); display: flex; align-items: center; justify-content: center; border-radius: 8px; color: #666; font-family: Arial, sans-serif;">Marketing Image ${i + 1}</div>`;
      processedHTML = processedHTML.replace(placeholder, fallbackImg);
    }
  }
  
  // If Gemini generated different placeholder text, try to replace those too
  const placeholderPatterns = [
    /\[Placeholder:[^\]]+\]/gi,
    /\[Image placeholder[^\]]*\]/gi,
    /\[Product image[^\]]*\]/gi,
    /\[Marketing image[^\]]*\]/gi,
    /Image placeholder here/gi,
    /Product image here/gi,
    /Marketing image here/gi
  ];
  
  // Replace generic placeholders with actual images
  let imageIndex = 0;
  placeholderPatterns.forEach(pattern => {
    processedHTML = processedHTML.replace(pattern, (match) => {
      if (imageIndex < images.length && images[imageIndex] && images[imageIndex].dataUrl) {
        const imgTag = `<img src="${images[imageIndex].dataUrl}" alt="Marketing Image ${imageIndex + 1}" style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">`;
        console.log(`Replaced generic placeholder "${match}" with image ${imageIndex + 1}`);
        imageIndex++;
        return imgTag;
      } else {
        const fallbackImg = `<div style="width: 100%; height: 300px; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); display: flex; align-items: center; justify-content: center; border-radius: 8px; color: #666; font-family: Arial, sans-serif;">Marketing Image ${imageIndex + 1}</div>`;
        imageIndex++;
        return fallbackImg;
      }
    });
  });
  
  // Check if there are any remaining placeholders
  const remainingPlaceholders = (processedHTML.match(/<!-- IMAGE_PLACEHOLDER_/g) || []).length;
  if (remainingPlaceholders > 0) {
    console.warn(`Warning: ${remainingPlaceholders} placeholders were not replaced`);
    // Try to replace any remaining placeholders with fallback images
    for (let i = 0; i < remainingPlaceholders; i++) {
      const placeholder = `<!-- IMAGE_PLACEHOLDER_${i + 1} -->`;
      if (processedHTML.includes(placeholder)) {
        const fallbackImg = `<div style="width: 100%; height: 300px; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); display: flex; align-items: center; justify-content: center; border-radius: 8px; color: #666; font-family: Arial, sans-serif;">Marketing Image ${i + 1}</div>`;
        processedHTML = processedHTML.replace(placeholder, fallbackImg);
        console.log(`Replaced remaining placeholder ${i + 1} with fallback`);
      }
    }
  }
  
  console.log('Image placeholder replacement completed');
  return processedHTML;
}

// Function to generate the HTML for the product website
async function generateWebsiteHTML(marketingData) {
  const { name, description, angles, images, keywords } = marketingData;
  
  console.log("Generating website with Gemini using placeholder approach...");
  
  try {
    // Check if we have an API key
    if (!GEMINI_API_KEY) {
      const hasApiKey = await getApiKey();
      if (!hasApiKey) {
        throw new Error('API key not found');
      }
    }
    
    // Create a prompt for Gemini to generate a website with placeholders
    // Safely handle the data to prevent template literal issues
    const safeName = (name || '').replace(/`/g, '\\`').replace(/\$/g, '\\$');
    const safeDescription = (description || '').replace(/`/g, '\\`').replace(/\$/g, '\\$');
    const safeKeywords = Array.isArray(keywords) ? keywords.join(', ') : (keywords || '');
    
    const anglesText = angles && angles.length > 0 
      ? angles.map(angle => {
          const safeTitle = (angle.title || '').replace(/`/g, '\\`').replace(/\$/g, '\\$');
          const safeDesc = (angle.description || '').replace(/`/g, '\\`').replace(/\$/g, '\\$');
          return `- ${safeTitle}: ${safeDesc}`;
        }).join('\n')
      : 'No marketing angles available';
    
    const imagesText = images && images.length > 0
      ? images.map((img, index) => {
          const safeDesc = (img.description || '').replace(/`/g, '\\`').replace(/\$/g, '\\$');
          return `- Image ${index + 1}: ${safeDesc}`;
        }).join('\n')
      : 'No marketing images available';

    const websitePrompt = `
You are a professional web developer. Create a complete, modern, responsive HTML website for a product.

PRODUCT INFORMATION:
- Name: ${safeName}
- Description: ${safeDescription}
- Keywords: ${safeKeywords}

MARKETING ANGLES:
${anglesText}

MARKETING IMAGES TO INTEGRATE:
${imagesText}

REQUIREMENTS:
1. Create a complete, standalone HTML file with embedded CSS
2. Use a modern, professional design with a color scheme that matches the product's style
3. Include a responsive layout that works on mobile and desktop
4. Include the following sections:
   - Header with product name and tagline
   - Hero section with the first marketing image as the main hero image
   - Marketing angles section highlighting the product benefits (integrate the second marketing image here)
   - Product features section (integrate the third marketing image here)
   - Call-to-action section
   - Footer with copyright and basic info
5. Use modern CSS features like flexbox or grid
6. Keep the design clean, professional and focused on showcasing the product
7. Include subtle animations or hover effects to enhance user experience
8. Ensure good typography and readability
9. Make sure the website is complete and ready to use
10. IMPORTANT: Use placeholder text for images instead of actual image data
11. For each image, use this EXACT placeholder format: <!-- IMAGE_PLACEHOLDER_1 -->, <!-- IMAGE_PLACEHOLDER_2 -->, <!-- IMAGE_PLACEHOLDER_3 -->, etc.
12. DO NOT use any other placeholder text like "[Placeholder: ...]" or "Image placeholder here" - ONLY use the exact format above
13. Create a cohesive design where the image placeholders enhance the marketing message and product presentation
14. Use appropriate alt text and styling for the image placeholders

CRITICAL: Return ONLY the raw HTML code. Do NOT wrap it in markdown code blocks, do NOT include \`\`\`html or \`\`\` tags, do NOT include any explanations or text before or after the HTML. Start directly with <!DOCTYPE html> and end with </html>.
`;

    // Prepare the request to Gemini API (text only, no images)
    const requestData = {
      contents: [{
        parts: [{ text: websitePrompt }]
      }]
    };
    
    // Send the request to Gemini API
    console.log('Sending website generation request to Gemini API (text only)...');
    const requestSize = JSON.stringify(requestData).length;
    console.log('Request size:', requestSize, 'characters');
    
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestData)
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('API error response:', errorText);
      throw new Error(`API request failed with status: ${response.status}. Details: ${errorText.substring(0, 200)}...`);
    }
    
    const data = await response.json();
    
    // Extract the HTML from the response
    let websiteHTML = '';
    if (data.candidates && data.candidates.length > 0 && 
        data.candidates[0].content && data.candidates[0].content.parts && 
        data.candidates[0].content.parts.length > 0) {
      websiteHTML = data.candidates[0].content.parts[0].text;
    } else {
      throw new Error('Unexpected API response structure');
    }
    
    // Clean up any markdown artifacts
    websiteHTML = cleanHTMLOutput(websiteHTML);
    
    // Replace placeholders with actual images
    console.log('Replacing image placeholders with actual images...');
    websiteHTML = replaceImagePlaceholders(websiteHTML, images);
    
    // No inline scripts to avoid CSP issues - the generated website will work without them
    
    console.log("Website generated successfully with placeholder approach");
    return websiteHTML;
    
  } catch (error) {
    console.error("Error generating website:", error);
    
    // Try fallback for any error
    console.log('Main generation failed, trying fallback...');
    try {
      return await generateWebsiteHTMLWithoutImages(marketingData);
    } catch (fallbackError) {
      console.error('Fallback also failed:', fallbackError);
      throw new Error(`Website generation failed completely: ${fallbackError.message}`);
    }
  }
}

// Fallback function to generate website without images (when request is too large)
async function generateWebsiteHTMLWithoutImages(marketingData) {
  const { name, description, angles, keywords } = marketingData;
  
  console.log("Generating website without images (fallback)...");
  
  try {
    // Check if we have an API key
    if (!GEMINI_API_KEY) {
      const hasApiKey = await getApiKey();
      if (!hasApiKey) {
        throw new Error('API key not found');
      }
    }
    
    // Create a simpler prompt for Gemini without images
    const websitePrompt = `
You are a professional web developer. Create a complete, modern, responsive HTML website for a product.

PRODUCT INFORMATION:
- Name: ${name}
- Description: ${description}
- Keywords: ${Array.isArray(keywords) ? keywords.join(', ') : ''}

MARKETING ANGLES:
${angles.map(angle => `- ${angle.title}: ${angle.description}`).join('\n')}

REQUIREMENTS:
1. Create a complete, standalone HTML file with embedded CSS
2. Use a modern, professional design with a color scheme that matches the product's style
3. Include a responsive layout that works on mobile and desktop
4. Include the following sections:
   - Header with product name and tagline
   - Hero section with a placeholder for product image
   - Marketing angles section highlighting the product benefits
   - Product features section
   - Call-to-action section
   - Footer with copyright and basic info
5. Use modern CSS features like flexbox or grid
6. Keep the design clean, professional and focused on showcasing the product
7. Include subtle animations or hover effects to enhance user experience
8. Ensure good typography and readability
9. Make sure the website is complete and ready to use
10. Use placeholder images or CSS gradients for visual elements
11. Create a cohesive design that focuses on the marketing message and product presentation

Return ONLY the complete HTML code with no explanations or markdown formatting.
`;

    const requestData = {
      contents: [{
        parts: [{ text: websitePrompt }]
      }]
    };
    
    // Send the request to Gemini API
    console.log('Sending fallback website generation request to Gemini API...');
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestData)
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('API error response:', errorText);
      throw new Error(`API request failed with status: ${response.status}. Details: ${errorText.substring(0, 200)}...`);
    }
    
    const data = await response.json();
    
    // Extract the HTML from the response
    let websiteHTML = '';
    if (data.candidates && data.candidates.length > 0 && 
        data.candidates[0].content && data.candidates[0].content.parts && 
        data.candidates[0].content.parts.length > 0) {
      websiteHTML = data.candidates[0].content.parts[0].text;
    } else {
      throw new Error('Unexpected API response structure');
    }
    
    // Clean up any markdown artifacts
    websiteHTML = cleanHTMLOutput(websiteHTML);
    
    // No inline scripts to avoid CSP issues - the generated website will work without them
    
    console.log("Fallback website generated successfully");
    return websiteHTML;
    
  } catch (error) {
    console.error("Error generating fallback website:", error);
    
    // Ultimate fallback - return a simple HTML template
    console.log('Fallback failed, using simple template...');
    return generateSimpleWebsiteTemplate(marketingData);
  }
}

// Ultimate fallback - simple HTML template
function generateSimpleWebsiteTemplate(marketingData) {
  const { name, description, angles, keywords } = marketingData;
  
  console.log("Generating simple website template...");
  
  return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${name}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        header { background: #4CAF50; color: white; padding: 20px 0; text-align: center; }
        h1 { font-size: 2.5em; margin-bottom: 10px; }
        .tagline { font-size: 1.2em; opacity: 0.9; }
        .hero { background: #f8f9fa; padding: 60px 0; text-align: center; }
        .hero h2 { font-size: 2em; margin-bottom: 20px; color: #4CAF50; }
        .hero p { font-size: 1.2em; max-width: 600px; margin: 0 auto; }
        .section { padding: 60px 0; }
        .section h2 { text-align: center; margin-bottom: 40px; color: #4CAF50; }
        .angles { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; }
        .angle { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .angle h3 { color: #4CAF50; margin-bottom: 15px; }
        .cta { background: #4CAF50; color: white; text-align: center; padding: 60px 0; }
        .cta h2 { margin-bottom: 20px; }
        .cta p { font-size: 1.2em; margin-bottom: 30px; }
        .btn { background: white; color: #4CAF50; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block; }
        footer { background: #333; color: white; text-align: center; padding: 20px 0; }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>${name}</h1>
            <p class="tagline">Your Perfect Product Solution</p>
        </div>
    </header>
    
    <section class="hero">
        <div class="container">
            <h2>Welcome to ${name}</h2>
            <p>${description}</p>
        </div>
    </section>
    
    <section class="section">
        <div class="container">
            <h2>Why Choose ${name}?</h2>
            <div class="angles">
                ${angles.map(angle => `
                <div class="angle">
                    <h3>${angle.title}</h3>
                    <p>${angle.description}</p>
                </div>
                `).join('')}
            </div>
        </div>
    </section>
    
    <section class="cta">
        <div class="container">
            <h2>Ready to Get Started?</h2>
            <p>Experience the difference that ${name} can make for you.</p>
            <a href="#" class="btn">Get Started Today</a>
        </div>
    </section>
    
    <footer>
        <div class="container">
            <p>&copy; 2024 ${name}. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>`;
}

// Load images from local storage
function loadSavedImages() {
  let storedImages = JSON.parse(localStorage.getItem('pixelPineappleImages')) || [];
  
  storedImages.forEach(function(item) {
    let img = document.createElement('img');
    img.src = item.dataUrl;
    img.title = item.filename;
    img.addEventListener('click', function() {
      let newTab = window.open();
      newTab.document.write('<img src="' + item.dataUrl + '" alt="' + item.filename + '" style="max-width: 100%;">');
    });
    window.gallery.appendChild(img);
  });
}
