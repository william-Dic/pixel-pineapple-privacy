// Save options to Chrome storage
function saveOptions() {
  const apiKey = document.getElementById('gemini-api-key').value.trim();
  const statusElement = document.getElementById('status');
  
  // Basic validation
  if (!apiKey) {
    statusElement.textContent = 'Please enter a valid API key.';
    statusElement.className = 'status error';
    setTimeout(() => {
      statusElement.className = 'status';
    }, 3000);
    return;
  }
  
  chrome.storage.sync.set(
    { geminiApiKey: apiKey },
    () => {
      // Update status to let user know options were saved
      statusElement.textContent = 'Settings saved successfully!';
      statusElement.className = 'status success';
      setTimeout(() => {
        statusElement.className = 'status';
      }, 3000);
    }
  );
}

// Restore saved options when the page loads
function restoreOptions() {
  chrome.storage.sync.get(
    { geminiApiKey: '' },  // Default empty string if not found
    (items) => {
      document.getElementById('gemini-api-key').value = items.geminiApiKey;
    }
  );
}

// Event listeners
document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('save').addEventListener('click', saveOptions);
