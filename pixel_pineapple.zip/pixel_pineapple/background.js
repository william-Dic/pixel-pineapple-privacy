// Listen for the extension icon to be clicked
chrome.action.onClicked.addListener(() => {
  // Open a new tab with our custom page
  chrome.tabs.create({ url: 'newtab.html' });
});
